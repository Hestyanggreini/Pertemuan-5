<?php

$nim = '202410101134';
$nama = 'Hesty Anggreini Tyas';
$penulis = 'Krisda Tiofani - Kompas.com';
$judul = 'Mengenal Nasi Mandhi, Nasi Rempah asal Arab yang dimasak dengan bara ! ';
$image = 'https://asset.kompas.com/crops/FwgrMzEhq8BrO2TIVwid5Atr7b8=/0x0:1000x667/750x500/data/photo/2020/08/01/5f24fb813c941.jpg';
$paragraf1 = "<strong> KOMPAS.com </strong> - Ada banyak masakan timur tengah yang umum ditemukan di Indonesia. Salah satunya adalah nasi mandhi. Nasi mandhi atau nasi mandi merupakan sajian khas Jazirah Arab yang terbuat dari beras dan lauk. Beras yang digunakan untuk membuat nasi mandhi adalah basmati. Executive Chef Luminor Hotel Pecenongan Dedi Tjahyadi mengatakan, warna nasi mandhi ada dua, yakni kuning dan putih. Biasanya kita pakai saffron, pewarna dari putik bunga, warnanya kuning. Jadi nantinya ada dua warna, kata Dedi saat ditemui Kompas.com Luminor Hotel Pecenongan, Selasa (29/3/2022). Campuran bahan, bumbu, dan rempah dalam nasi mandhi membuat sajian ini terasa gurih serta aromanya cukup kuat. Salah satu bahan yang digunakan untuk membuat nasi mandhi adalah daging kambing atau daging ayam. Sementara beberapa rempah dalam nasi mandhi adalah lada, jintan, ketumbar, cengkih, dan kapulaga.";
$paragraf2 = "<strong> Dimasak pakai bara</strong> <br> Selain karena rempah, aroma nasi mandhi juga berasal dari pemasakannya yang menggunakan bara. Cara membuat nasi mandhi diawali dengan memasak daging kambing untuk mendapatkan kaldunya. Setelah itu, bumbu dan beberapa rempah yang digunakan harus ditumis sebentar, lalu ditambahkan beras dan kaldu kambing atau ayam. Kaldu dimasak bersama tumisan di atas api kecil, setelah mendidih barulah bumbu dimasukkan. Panas api yang digunakan untuk membuat nasi mandhi berasal dari bara sehingga aroma asapnya lumayan tercium. Nasi, terus ada minyak, di atasnya ada arang yang sudah membara, terus kita masukkin ke minyak itu, terus ditutup, jadi aroma asapnya masuk ke dalam. Itu aslinya, ujar Dedi. Meski dimasak dengan suhu panas medium, proses memasak nasi mandhi hanya memakan waktu selama 45-60 menit saja. Setelah matang, nasi mandhi akan disajikan bersama daging kambing yang sudah dimasak bersama, lalu ditaburi kismis sebagai sentuhan akhir. Memang hampir semuanya nasi-nasian dari Jazirah Arab pasti pakai kacang-kacangan sama kismis. Itu sudah pasti, ujar Dedi.";
?>

<!doctype html>
<html lang="en">
<head>
<style>
  img {
    border-radius: 6px;
    max-width: 600px;
    max-height: 600px;
  }
  div {
    text-align: justify;
    text-justify: inter-word;
  }
  .card {
    padding: 20px;
    box-shadow: 5px 5px 5px gray;
    border-radius: 4px;
  }

  .penulis {
    font-style: italic;
  }

  .p {
    text-indent: 12px;
  }
</style>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <title>Tugas Index Page</title>
</head>

<body>

  <main class="container my-3">
    <section class="text-center card">
      <h4><?= $nama . " - " . $nim ?></h4>
    </section>

    <br>

    <section class="judul text-center">
      <h3 class="text-center"><?= $judul ?></h3>
        <p class="penulis"><?= $penulis ?></p>
      <img src="<?= $image ?>" alt="" srcset="">
    </section>

    <section class="my-3 card">
      <div class="p">
        <p><?= $paragraf1 ?></p>
      </div>
      <div class="p">
        <p><?= $paragraf2 ?></p>
      </div>
    </section>

  </main>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>